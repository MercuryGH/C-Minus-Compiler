void main() {
    int i;

    i = 1;
    while (i > 0) {
        i = i + 1;
    }
}