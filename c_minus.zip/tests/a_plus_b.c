int gl;

int main()
{
    int a;
    int b;

    a = input();
    b = input();

    output(a + b);

    return 0;
}
